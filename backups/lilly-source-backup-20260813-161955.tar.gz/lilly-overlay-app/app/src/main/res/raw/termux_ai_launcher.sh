#!/usr/bin/env bash
# Termux AI Server - Launcher (embedded in APK)
# This is a lightweight wrapper that sources the manager
export PATH="$HOME/ai-server:$PATH"
MANAGER="$HOME/ai-server/scripts/llama-server-manager.sh"
if [[ -f "$MANAGER" ]]; then
    source "$MANAGER" "$@"
else
    echo "[error] Manager not found at $MANAGER"
    echo "Run setup first: bash ~/ai-server/scripts/termux_llama_setup.sh"
    exit 1
fi
