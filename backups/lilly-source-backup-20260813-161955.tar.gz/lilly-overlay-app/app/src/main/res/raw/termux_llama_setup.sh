#!/usr/bin/env bash
# Termux AI Server - Quick Setup (embedded in APK)
set -euo pipefail

INSTALL_DIR="$HOME/ai-server"
REPO="https://github.com/ggml-org/llama.cpp"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${GREEN}[1/4]${NC} Installing dependencies..."
pkg update -y 2>/dev/null || apt update -y
pkg install -y git cmake clang make pkg-config curl wget python 2>/dev/null || \
apt install -y git cmake clang make pkg-config curl wget python

echo -e "${GREEN}[2/4]${NC} Building llama.cpp (CPU-only)..."
if [[ -d "$INSTALL_DIR/llama.cpp" ]]; then
    cd "$INSTALL_DIR/llama.cpp" && git pull --ff-only 2>/dev/null || true
else
    mkdir -p "$INSTALL_DIR"
    git clone --depth 1 "$REPO" "$INSTALL_DIR/llama.cpp"
    cd "$INSTALL_DIR/llama.cpp"
fi
cmake -B build -DLLAMA_CPU=ON -DCMAKE_BUILD_TYPE=Release 2>&1 | tail -2
cmake --build build --config Release -j$(nproc) 2>&1 | tail -2

echo -e "${GREEN}[3/4]${NC} Setting up directories..."
mkdir -p "$INSTALL_DIR"/{models,logs,scripts,config}

# Move any existing GGUF models
for f in "$HOME"/*.gguf; do
    [[ -f "$f" ]] && mv "$f" "$INSTALL_DIR/models/" 2>/dev/null || true
done

echo -e "${GREEN}[4/4]${NC} Creating PATH entry..."
if ! grep -q "ai-server" "$HOME/.bashrc" 2>/dev/null; then
    echo 'export PATH="$HOME/ai-server:$PATH"' >> "$HOME/.bashrc"
fi

echo ""
echo -e "${GREEN}Done!${NC} Run: ai-server start"
echo "Models dir: $INSTALL_DIR/models/"
