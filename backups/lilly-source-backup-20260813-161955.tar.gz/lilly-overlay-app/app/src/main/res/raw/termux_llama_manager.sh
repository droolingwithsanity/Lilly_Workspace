#!/usr/bin/env bash
# llama.cpp Server Manager (embedded in APK)
set -euo pipefail

INSTALL_DIR="${LLAMA_INSTALL_DIR:-$HOME/ai-server}"
LLAMA_DIR="$INSTALL_DIR/llama.cpp"
SERVER_BIN="$LLAMA_DIR/build/bin/llama-server"
MODEL_DIR="$INSTALL_DIR/models"
LOG_DIR="$INSTALL_DIR/logs"
PID_FILE="$INSTALL_DIR/.server.pid"

HOST="${LLAMA_HOST:-127.0.0.1}"
PORT="${LLAMA_PORT:-8080}"
MODEL="${LLAMA_MODEL:-}"
THREADS="${LLAMA_THREADS:-$(nproc)}"
CTX="${LLAMA_CTX:-4096}"
PARALLEL="${LLAMA_PARALLEL:-2}"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'
log() { echo -e "${GREEN}[ai-server]${NC} $*"; }
err() { echo -e "${RED}[error]${NC} $*" >&2; }

is_running() {
    [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null
}

pick_model() {
    if [[ -n "$MODEL" && -f "$MODEL" ]]; then echo "$MODEL"; return; fi
    local models=()
    while IFS= read -r f; do models+=("$f"); done < <(
        find "$MODEL_DIR" -name "*.gguf" -not -name "ggml-vocab*" 2>/dev/null | sort
    )
    if [[ ${#models[@]} -eq 0 ]]; then err "No models in $MODEL_DIR"; exit 1; fi
    if [[ ${#models[@]} -eq 1 ]]; then echo "${models[0]}"; return; fi
    echo "Select model:"
    local i=1
    for m in "${models[@]}"; do
        echo "  $i) $(basename "$m") ($(du -h "$m" | cut -f1))"
        ((i++))
    done
    read -rp "Choice [1]: " c; c=${c:-1}
    echo "${models[$((c-1))]}"
}

start() {
    if is_running; then log "Already running (PID: $(cat "$PID_FILE"))"; return 0; fi
    [[ -x "$SERVER_BIN" ]] || { err "llama-server not built. Run setup first."; exit 1; }

    local model; model=$(pick_model)
    mkdir -p "$LOG_DIR"

    log "Starting... Model: $(basename "$model") Listen: $HOST:$PORT"

    nohup "$SERVER_BIN" \
        --host "$HOST" --port "$PORT" \
        --model "$model" \
        --threads "$THREADS" --ctx-size "$CTX" \
        --parallel "$PARALLEL" \
        >> "$LOG_DIR/server.log" 2>&1 &
    echo $! > "$PID_FILE"

    local i=0
    while [[ $i -lt 30 ]]; do
        if curl -sf --max-time 2 "http://$HOST:$PORT/health" >/dev/null 2>&1; then
            log "Ready at http://$HOST:$PORT"
            return 0
        fi
        sleep 1; ((i++))
    done
    err "Failed to start. Check: $LOG_DIR/server.log"
    return 1
}

stop() {
    if is_running; then
        kill "$(cat "$PID_FILE")" 2>/dev/null
        rm -f "$PID_FILE"
        log "Stopped"
    else
        log "Not running"
    fi
}

case "${1:-help}" in
    start)   start ;;
    stop)    stop ;;
    restart) stop; sleep 1; start ;;
    status)
        if is_running; then
            log "Running (PID: $(cat "$PID_FILE"))"
            curl -sf "http://$HOST:$PORT/health" >/dev/null 2>&1 && echo " Health: OK"
        else log "Stopped"; fi
        ;;
    test)
        curl -sf "http://$HOST:$PORT/v1/chat/completions" \
            -H "Content-Type: application/json" \
            -d '{"model":"local","messages":[{"role":"user","content":"Hello in 3 words"}],"max_tokens":20}' \
            | python3 -m json.tool 2>/dev/null || err "API not responding"
        ;;
    *) echo "Usage: $0 {start|stop|restart|status|test}" ;;
esac
