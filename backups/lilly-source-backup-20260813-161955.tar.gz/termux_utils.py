#!/usr/bin/env python3
"""
Termux utilities for async operations with native Termux commands.

Provides async/await wrappers for common Termux operations:
- Battery status
- WiFi scanning
- Location services
- Sensor data
- Audio recording
- Screen capture
- File operations

All functions use asyncio for non-blocking operations.
"""

import asyncio
import json
import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


async def run_termux_command(
    command: Union[str, List[str]], timeout: float = 5.0
) -> Dict[str, Any]:
    """Execute a Termux command asynchronously.

    Args:
        command: Command to run (string or list)
        timeout: Command timeout in seconds

    Returns:
        Dict with output, error, and returncode
    """
    try:
        process = await asyncio.create_subprocess_exec(
            *([command] if isinstance(command, str) else command),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=timeout
            )
            return {
                "output": stdout.decode("utf-8", errors="replace").strip(),
                "error": stderr.decode("utf-8", errors="replace").strip(),
                "returncode": process.returncode,
                "timestamp": time.time(),
            }
        except asyncio.TimeoutError:
            process.kill()
            stdout, stderr = await process.communicate()
            return {
                "error": f"Timeout after {timeout}s",
                "output": stdout.decode("utf-8", errors="replace").strip()
                if stdout
                else "",
                "returncode": -1,
                "timestamp": time.time(),
            }
    except Exception as e:
        logger.error(f"Termux command failed: {e}")
        return {
            "error": str(e),
            "output": "",
            "returncode": -1,
            "timestamp": time.time(),
        }


async def get_battery() -> Dict[str, Any]:
    """Get battery information."""
    try:
        result = await run_termux_command(["termux-battery-status"])

        if result["returncode"] == 0 and result["output"]:
            battery_data = (
                json.loads(result["output"])
                if result["output"].strip().startswith("{")
                else {}
            )
            return battery_data
        else:
            logger.warning(f"Battery command failed: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to get battery: {e}")

    return {"level": 50, "temperature": 25.0, "status": "unknown", "health": "good"}


async def get_wifi_scan() -> List[Dict[str, Any]]:
    """Scan for WiFi networks."""
    try:
        result = await run_termux_command(["termux-wifi-scan"])

        if result["returncode"] == 0 and result["output"]:
            wifi_data = (
                json.loads(result["output"])
                if result["output"].strip().startswith("[")
                else []
            )
            return wifi_data
        else:
            logger.warning(f"WiFi scan failed: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to scan WiFi: {e}")

    return []


async def get_location() -> Dict[str, Any]:
    """Get current location."""
    try:
        result = await run_termux_command(["termux-location"])

        if result["returncode"] == 0 and result["output"]:
            location_data = (
                json.loads(result["output"])
                if result["output"].strip().startswith("{")
                else {}
            )
            return location_data
        else:
            logger.warning(f"Location command failed: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to get location: {e}")

    return {"latitude": 0.0, "longitude": 0.0, "accuracy": 0.0, "provider": "unknown"}


async def list_sensors() -> List[str]:
    """List available sensors."""
    sensors = []
    try:
        result = await run_termux_command(["termux-sensor", "-l"])
        if result["returncode"] == 0:
            sensors = [s.strip() for s in result["output"].split("\n") if s.strip()]
    except Exception as e:
        logger.error(f"Failed to list sensors: {e}")

    if not sensors:
        sensors = [
            "accelerometer",
            "gyroscope",
            "magnetometer",
            "pressure",
            "temperature",
            "proximity",
            "light",
            "humidity",
        ]

    return sensors


async def read_sensor(sensor_name: str) -> Dict[str, Any]:
    """Read data from a specific sensor.

    Args:
        sensor_name: Name of the sensor to read

    Returns:
        Dict containing sensor data
    """
    try:
        result = await run_termux_command(["termux-sensor", "-s", sensor_name])

        if result["returncode"] == 0 and result["output"]:
            sensor_data = (
                json.loads(result["output"])
                if result["output"].strip().startswith("{")
                else {}
            )
            return sensor_data
        else:
            logger.warning(f"Sensor read failed for {sensor_name}: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to read sensor {sensor_name}: {e}")

    return {
        "sensor": sensor_name,
        "value": 0.0,
        "unit": "unknown",
        "timestamp": time.time(),
    }


async def capture_audio() -> Dict[str, Any]:
    """Capture audio using termux-audio-recorder."""
    try:
        output_file = Path("/tmp/lilly_audio.raw")
        result = await run_termux_command(
            [
                "termux-audio-recorder",
                "-r",
                "raw",
                "-c",
                "1",
                "-b",
                "320000",
                "-p",
                "16000",
                "-d",
                "1",
                "-f",
                str(output_file),
            ],
            timeout=5.0,
        )

        if output_file.exists():
            with open(output_file, "rb") as f:
                audio_data = f.read()
            output_file.unlink()
            return {
                "audio_base64": audio_data.hex(),
                "format": "raw16khz_mono32kbps",
                "duration_ms": 1000,
                "timestamp": time.time(),
            }
        else:
            logger.warning(f"Audio capture failed: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to capture audio: {e}")

    return {
        "audio_base64": "",
        "format": "raw16khz_mono32kbps",
        "duration_ms": 0,
        "timestamp": time.time(),
    }


async def capture_screen() -> Dict[str, Any]:
    """Capture screen using termux-screencap."""
    try:
        output_file = Path("/tmp/lilly_screenshot.png")
        result = await run_termux_command(
            ["termux-screencap", "-p", str(output_file)], timeout=5.0
        )

        if output_file.exists():
            with open(output_file, "rb") as f:
                image_data = f.read()
            output_file.unlink()
            return {
                "image_base64": image_data.hex(),
                "format": "png",
                "width": 1080,
                "height": 1920,
                "timestamp": time.time(),
            }
        else:
            logger.warning(f"Screen capture failed: {result['error']}")
    except Exception as e:
        logger.error(f"Failed to capture screen: {e}")

    return {
        "image_base64": "",
        "format": "png",
        "width": 0,
        "height": 0,
        "timestamp": time.time(),
    }


async def run_command(command: str) -> Dict[str, Any]:
    """Run a Termux command."""
    try:
        result = await run_termux_command(command, timeout=30.0)
        return result
    except Exception as e:
        logger.error(f"Command execution failed: {e}")
        return {
            "error": str(e),
            "output": "",
            "returncode": -1,
            "timestamp": time.time(),
        }


# Monkey patch time module for timestamp support
import time

__all__ = [
    "run_termux_command",
    "get_battery",
    "get_wifi_scan",
    "get_location",
    "list_sensors",
    "read_sensor",
    "capture_audio",
    "capture_screen",
    "run_command",
]
